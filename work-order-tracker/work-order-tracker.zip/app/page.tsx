'use client';

import { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { createBrowserClient } from '@supabase/ssr';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import {
  Users, Activity, Plus, List, Database, RefreshCw, Archive,
  ShieldAlert, Check, X, ListTodo, BarChart3, ArrowUpRight,
  ArrowDownRight, MinusCircle, Calendar, ChevronDown, Search,
  Download, ChevronRight, Inbox, Clock, TrendingUp, Wifi, WifiOff,
  Zap, Signal
} from 'lucide-react';
import { format, getISOWeek, formatDistanceToNow } from 'date-fns';
import { id as indonesia } from 'date-fns/locale';
import { Role, PERMISSIONS, hasAccess } from '@/lib/permissions';
import AlertBanner from '@/components/AlertBanner';
import { useRealtimeTable } from '@/hooks/useRealtimeTable';
import { toast } from 'sonner';

const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false });

// BUG-05 fix: static config only — isWeekA_Morning dihitung di dalam komponen
// agar selalu pakai tanggal saat render, bukan saat module dimuat
const TEAM_CONFIG = {
  teamA: ['Anan', 'Shidiq'],
  teamB: ['Ilham', 'Andi'],
};

// ─── REALTIME STATUS INDICATOR ───────────────────────────────
function LivePill({ connected }: { connected: boolean }) {
  return (
    <div
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase transition-all duration-500"
      style={connected
        ? { background: 'rgba(16,185,129,0.12)', color: '#10b981', border: '1px solid rgba(16,185,129,0.3)' }
        : { background: 'rgba(255,255,255,0.05)', color: '#4a5568', border: '1px solid rgba(255,255,255,0.08)' }
      }
    >
      <span className="relative flex w-1.5 h-1.5">
        {connected && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60" />}
        <span className={`relative rounded-full w-1.5 h-1.5 ${connected ? 'bg-emerald-400' : 'bg-slate-500'}`} />
      </span>
      {connected ? 'Live' : 'Connecting'}
    </div>
  );
}

// ─── ANIMATED COUNTER — UX-03: real count-up via rAF ────────
function AnimatedNumber({ value, prefix = '', suffix = '' }: { value: number | string; prefix?: string; suffix?: string }) {
  const numVal = typeof value === 'number' ? value : parseInt(String(value)) || 0;
  const isNumeric = typeof value === 'number';
  const [display, setDisplay] = useState(numVal);
  const prevRef = useRef(numVal);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    if (!isNumeric) { setDisplay(value as any); return; }
    const from = prevRef.current;
    const to = numVal;
    if (from === to) return;
    prevRef.current = to;
    const duration = 650;
    const startTime = performance.now();
    const tick = (now: number) => {
      const t = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3); // easeOutCubic
      setDisplay(Math.round(from + (to - from) * eased));
      if (t < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [numVal, isNumeric, value]);

  return <span>{prefix}{display}{suffix}</span>;
}

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [userRole, setUserRole] = useState<Role | null>(null);
  const [userFullName, setUserFullName] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  // BUG-03: tanggal di header terupdate setiap menit
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  // BUG-04: ticker untuk paksa re-render "Update terakhir" setiap 30 detik
  const [, setTick] = useState(0);
  // BUG-05: isWeekA_Morning dihitung saat render, bukan saat module dimuat
  const isWeekA_Morning = getISOWeek(new Date()) % 2 !== 0;

  const [stats, setStats] = useState({
    totalClient: 0,
    totalVlanUsed: 0,
    totalVlanFree: 0,
    growthMonth: 0,
    logsToday: 0,
    woPending: 0
  });

  const [initialRecentLogs, setInitialRecentLogs] = useState<any[]>([]);
  const [initialClients, setInitialClients] = useState<any[]>([]);
  const [initialWorkOrders, setInitialWorkOrders] = useState<any[]>([]);

  const [chartTab, setChartTab] = useState<'CLIENT' | 'CAPACITY'>('CLIENT');
  const [chartData, setChartData] = useState<any>({ client: [], capacity: [] });
  const [chartSummary, setChartSummary] = useState({ pasang: 0, putus: 0, BerhentiSementara: 0, upgrade: 0, downgrade: 0 });

  const [myInboxTickets, setMyInboxTickets] = useState<any[]>([]);
  const [pendingApprovals, setPendingApprovals] = useState<any[]>([]);
  const [showInbox, setShowInbox] = useState(false);
  const [expandedTicket, setExpandedTicket] = useState<string | null>(null);
  const [searchTicket, setSearchTicket] = useState('');

  // ── FITUR-01: Insiden Backbone Aktif ──────────────────────
  const [backboneCount, setBackboneCount] = useState(0);
  // ── FITUR-02: WO status breakdown ─────────────────────────
  const [woBreakdown, setWoBreakdown] = useState<Record<string, number>>({});
  // ── FITUR-04: Status Odoo API Key ─────────────────────────
  const [odooKeyStatus, setOdooKeyStatus] = useState<'loading' | 'active' | 'missing'>('loading');
  // ── FITUR-05: Timestamp last sync ─────────────────────────
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  // ── FITUR-06: Trend vs bulan lalu ─────────────────────────
  const [prevMonthGrowth, setPrevMonthGrowth] = useState(0);
  // ── UX-01/FITUR-07: theme-aware chart colors ───────────────
  const [isDark, setIsDark] = useState(true);

  // UX-05 fix: bungkus useMemo agar instance tidak dibuat ulang tiap render
  const supabase = useMemo(() => createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
  ), []);

  // ── REALTIME SUBSCRIPTIONS ─────────────────────────────────
  const realtimeLogs = useRealtimeTable('Log_Aktivitas', initialRecentLogs, ['INSERT']);
  const realtimeClients = useRealtimeTable('Data Client Corporate', initialClients, ['INSERT', 'DELETE']);
  const realtimeWorkOrders = useRealtimeTable('Report Bulanan', initialWorkOrders, ['INSERT', 'UPDATE', 'DELETE']);

  const recentLogs = realtimeLogs.slice(0, 8);

  // ── DERIVED REALTIME STATS ─────────────────────────────────
  const realtimeStats = {
    ...stats,
    totalClient: realtimeClients.length > 0 ? realtimeClients.length : stats.totalClient,
    woPending: realtimeWorkOrders.filter((wo: any) =>
      ['PENDING', 'OPEN', 'PROGRESS', 'ON PROGRESS'].includes(wo.STATUS)
    ).length || stats.woPending,
    logsToday: realtimeLogs.filter((log: any) => {
      const today = new Date().toISOString().split('T')[0];
      return log.created_at?.startsWith(today);
    }).length || stats.logsToday,
  };

  // ── UPDATE TIMESTAMP saat data realtime berubah ────────────
  useEffect(() => {
    setLastUpdated(new Date());
  }, [realtimeLogs.length, realtimeClients.length, realtimeWorkOrders.length]);

  // BUG-05: gunakan isWeekA_Morning dari state komponen (bukan module-level)
  const morningSquad = isWeekA_Morning ? TEAM_CONFIG.teamA : TEAM_CONFIG.teamB;
  const afternoonSquad = isWeekA_Morning ? TEAM_CONFIG.teamB : TEAM_CONFIG.teamA;

  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 11) return 'Selamat Pagi';
    if (h < 15) return 'Selamat Siang';
    if (h < 18) return 'Selamat Sore';
    return 'Selamat Malam';
  };

  const handleApprovalAction = async (id: number, action: 'APPROVE' | 'REJECT') => {
    if (!hasAccess(userRole, PERMISSIONS.OVERVIEW_ACTION)) return;
    try {
      if (action === 'APPROVE') {
        await supabase.from('Ignored_Items').update({ STATUS: 'APPROVED' }).eq('id', id);
      } else {
        // BUG-09 fix: hanya ubah STATUS → 'REJECTED', tidak hapus data permanen
        await supabase.from('Ignored_Items').update({ STATUS: 'REJECTED' }).eq('id', id);
      }
      setPendingApprovals(prev => prev.filter(item => item.id !== id));
      toast.success(action === 'APPROVE' ? 'Request disetujui!' : 'Request ditolak.');
    } catch (err) {
      console.error('Approval Error:', err);
      toast.error('Gagal memproses approval');
    }
  };

  async function handleSyncSheet() {
    if (!hasAccess(userRole, PERMISSIONS.OVERVIEW_ACTION)) {
      toast.error('Izin ditolak', { description: 'Hanya Admin/NOC yang bisa sinkronisasi.' });
      return;
    }
    setIsSyncing(true);
    const toastId = toast.loading('Menyinkronkan data ke Google Sheets...');
    const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbz_Kamhv6OJiN7bAtzzA2Z-tzkWvekJakQNRsPVGU1Xwmn_jePm2ZyiSf_RdU_5zUpr/exec';
    const syncTargets = [
      { name: 'Report Bulanan', sheetName: '2026', id: '1Yqr6tlJGo2yHE-9FJ_mCMpnehV-0Lpo2oiGUPWqAXOE' },
      { name: 'Berlangganan 2026', sheetName: 'Berlangganan 2026', id: '19PWdBv4RQgHqxa2Bf7-OQuOeSdTumLb01bR0fhQhkb0' },
      { name: 'Berhenti Berlangganan 2026', sheetName: 'Berhenti Berlangganan 2026', id: '19PWdBv4RQgHqxa2Bf7-OQuOeSdTumLb01bR0fhQhkb0' },
      { name: 'Berhenti Sementara 2026', sheetName: 'Berhenti Sementara 2026', id: '19PWdBv4RQgHqxa2Bf7-OQuOeSdTumLb01bR0fhQhkb0' },
      { name: 'Upgrade 2026', sheetName: 'Upgrade 2026', id: '19PWdBv4RQgHqxa2Bf7-OQuOeSdTumLb01bR0fhQhkb0' },
      { name: 'Downgrade 2026', sheetName: 'Downgrade 2026', id: '19PWdBv4RQgHqxa2Bf7-OQuOeSdTumLb01bR0fhQhkb0' },
    ];
    try {
      for (const target of syncTargets) {
        await fetch('/api/sync-spreadsheet', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tableTarget: target.name, sheetName: target.sheetName,
            spreadsheetId: target.id, googleScriptUrl: GOOGLE_SCRIPT_URL
          })
        });
      }
      toast.success('Sync berhasil!', { id: toastId, description: 'Data Supabase berhasil disinkronkan ke Google Sheets.' });
      setLastSyncTime(new Date()); // FITUR-05
    } catch {
      toast.error('Sinkronisasi gagal', { id: toastId, description: 'Terjadi kesalahan saat menghubungi Google Sheets.' });
    } finally {
      setIsSyncing(false);
    }
  }

  const fetchDashboardData = useCallback(async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      let currentUserName = '';
      let currentUserRole: Role | null = null;

      if (user) {
        const { data: profile } = await supabase.from('profiles').select('role, full_name').eq('id', user.id).single();
        if (profile) {
          setUserRole(profile.role as Role);
          setUserFullName(profile.full_name);
          currentUserName = profile.full_name;
          currentUserRole = profile.role as Role;
        }
      }

      if (hasAccess(currentUserRole, PERMISSIONS.OVERVIEW_ACTION)) {
        const { data: approvals } = await supabase.from('Ignored_Items').select('*').eq('STATUS', 'PENDING').order('created_at', { ascending: false });
        if (approvals) setPendingApprovals(approvals);
      }

      if (currentUserName) {
        let query = supabase.from('inbox_tugas').select('*');
        if (currentUserRole !== 'SUPER_DEV') {
          query = query.eq('assigned_to', currentUserName).eq('status', 'OPEN');
        }
        const { data: inboxData } = await query.order('created_at', { ascending: false });
        if (inboxData) {
          const enrichedTickets = await Promise.all(inboxData.map(async (ticket) => {
            const { data: woDetails } = await supabase.from('Report Bulanan').select('id, "SUBJECT WO", STATUS, KETERANGAN').in('id', ticket.wo_ids);
            const allSolved = woDetails?.every(wo => wo.STATUS === 'SOLVED' || wo.STATUS === 'CLOSED');
            // BUG-01 fix: woDetails bisa null jika query gagal — gunakan optional chaining
            if (allSolved && (woDetails?.length ?? 0) > 0 && ticket.status !== 'SOLVED') {
              await supabase.from('inbox_tugas').update({ status: 'SOLVED' }).eq('id', ticket.id);
            }
            return { ...ticket, details: woDetails || [] };
          }));
          setMyInboxTickets(enrichedTickets);
        }
      }

      const { count: clientCount } = await supabase.from('Data Client Corporate').select('*', { count: 'exact', head: true });
      const { count: pendingCount } = await supabase.from('Report Bulanan').select('id', { count: 'exact', head: true }).in('STATUS', ['PENDING', 'OPEN', 'PROGRESS', 'ON PROGRESS']);

      // ── Fetch semua data client & WO untuk realtime tracking ──
      const { data: allClients } = await supabase.from('Data Client Corporate').select('id');
      const { data: allWOs } = await supabase.from('Report Bulanan').select('id, STATUS');
      if (allClients) setInitialClients(allClients);
      if (allWOs) setInitialWorkOrders(allWOs);

      const tables = ['Berlangganan 2026', 'Berhenti Berlangganan 2026', 'Berhenti Sementara 2026', 'Upgrade 2026', 'Downgrade 2026'];
      const responses = await Promise.all(tables.map(t => supabase.from(t).select('TANGGAL')));

      const groupByMonth = (data: any[]) => {
        const months = new Array(12).fill(0);
        data?.forEach(row => { if (row.TANGGAL) months[new Date(row.TANGGAL).getMonth()]++; });
        return months;
      };
      const d = responses.map(r => groupByMonth(r.data || []));

      setChartData({
        client: [{ name: 'Berlangganan', data: d[0] }, { name: 'Berhenti', data: d[1] }, { name: 'Berhenti Sementara', data: d[2] }],
        capacity: [{ name: 'Upgrade', data: d[3] }, { name: 'Downgrade', data: d[4] }]
      });
      setChartSummary({
        pasang: d[0].reduce((a, b) => a + b, 0), putus: d[1].reduce((a, b) => a + b, 0),
        BerhentiSementara: d[2].reduce((a, b) => a + b, 0),
        upgrade: d[3].reduce((a, b) => a + b, 0), downgrade: d[4].reduce((a, b) => a + b, 0),
      });

      const vlanTables = ['Daftar Vlan 1-1000', 'Daftar Vlan 1000+', 'Daftar Vlan 2000+', 'Daftar Vlan 3000+', 'Daftar Vlan 3500+', 'Daftar Vlan 4003+'];
      let totalUsed = 0, totalAllVlan = 0;
      const vlanResponses = await Promise.all(vlanTables.map(t => supabase.from(t).select('NAME')));
      vlanResponses.forEach(res => {
        if (res.data) {
          totalAllVlan += res.data.length;
          totalUsed += res.data.filter(r => {
            const name = (r.NAME || '').toUpperCase();
            return name && name !== '-' && name !== 'AVAILABLE' && name !== '';
          }).length;
        }
      });

      const todayStart = new Date().toISOString().split('T')[0] + 'T00:00:00Z';
      const { data: logs } = await supabase.from('Log_Aktivitas').select('*').order('created_at', { ascending: false }).limit(8);
      const { count: countToday } = await supabase.from('Log_Aktivitas').select('id', { count: 'exact', head: true }).gte('created_at', todayStart);

      setStats({
        totalClient: clientCount || 0,
        totalVlanUsed: totalUsed,
        totalVlanFree: totalAllVlan - totalUsed,
        growthMonth: d[0][new Date().getMonth()],
        logsToday: countToday || 0,
        woPending: pendingCount || 0
      });
      setInitialRecentLogs(logs || []);

      // ── FITUR-01: hitung insiden backbone aktif ────────────
      const { data: bbRows } = await supabase
        .from('Report Backbone')
        .select('"NOMOR TICKET", "Status Case"');
      if (bbRows) {
        const activeStatuses = ['OPEN', 'ON PROGRESS', 'PENDING'];
        const activeTickets = new Set(
          bbRows
            .filter(r => activeStatuses.includes(r['Status Case'] || ''))
            .map(r => r['NOMOR TICKET'])
        );
        setBackboneCount(activeTickets.size);
      }

      // ── FITUR-02: WO status breakdown ─────────────────────
      const { data: wosAll } = await supabase.from('Report Bulanan').select('STATUS');
      if (wosAll) {
        const bd: Record<string, number> = {};
        wosAll.forEach(w => { const s = w.STATUS || 'UNKNOWN'; bd[s] = (bd[s] || 0) + 1; });
        setWoBreakdown(bd);
      }

      // ── FITUR-06: trend vs bulan lalu ─────────────────────
      const lastMonthIdx = new Date().getMonth() === 0 ? 11 : new Date().getMonth() - 1;
      setPrevMonthGrowth(d[0][lastMonthIdx]);
    } catch (err) {
      console.error('Dashboard Error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchDashboardData(); }, []);

  // BUG-02 fix: cek koneksi Supabase Realtime yang sesungguhnya
  // isLive = true hanya saat channel benar-benar terhubung (status 'SUBSCRIBED')
  useEffect(() => {
    const channel = supabase
      .channel('__connection_health__')
      .subscribe((status) => {
        setIsLive(status === 'SUBSCRIBED');
      });
    return () => { supabase.removeChannel(channel); };
  }, []);

  // BUG-03 fix: update tanggal di header setiap 60 detik
  useEffect(() => {
    const timer = setInterval(() => setCurrentDate(new Date()), 60_000);
    return () => clearInterval(timer);
  }, []);

  // BUG-04 fix: paksa re-render "Update terakhir" setiap 30 detik
  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 30_000);
    return () => clearInterval(timer);
  }, []);

  // UX-01/FITUR-07: deteksi tema dark/light secara reaktif lewat MutationObserver
  useEffect(() => {
    const check = () => setIsDark(!document.documentElement.classList.contains('light'));
    check();
    const obs = new MutationObserver(check);
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => obs.disconnect();
  }, []);

  // FITUR-04: cek status Odoo API Key user yang sedang login
  useEffect(() => {
    fetch('/api/my-odoo-key')
      .then(r => r.json())
      .then(d => setOdooKeyStatus(d.hasKey ? 'active' : 'missing'))
      .catch(() => setOdooKeyStatus('missing'));
  }, []);

  const handleDownloadInbox = () => {
    if (myInboxTickets.length === 0) return toast.info('Tidak ada tugas untuk diunduh.');
    let content = `TO DO LIST GRUP - ${userFullName}\nGenerated: ${format(new Date(), 'dd MMM yyyy HH:mm')}\n==========================\n\n`;
    myInboxTickets.forEach((ticket) => {
      content += `${ticket.id_tiket_custom || 'BATCH'} (PIC: ${ticket.assigned_to})\n`;
      ticket.details.forEach((wo: any) => { content += `- [${wo.STATUS}] ${wo['SUBJECT WO']}\n`; });
      content += `\n--------------------------\n`;
    });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([content], { type: 'text/plain' }));
    link.download = `Monitoring_Inbox_${userFullName}.txt`;
    link.click();
  };

  if (loading) return <DashboardSkeleton />;

  // VLAN usage percentage
  const vlanUsagePercent = realtimeStats.totalVlanFree + realtimeStats.totalVlanUsed > 0
    ? Math.round((realtimeStats.totalVlanUsed / (realtimeStats.totalVlanFree + realtimeStats.totalVlanUsed)) * 100)
    : 0;

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-base)', fontFamily: 'var(--font-sans)' }}>
      <style>{`
        @keyframes countUp { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeSlideIn { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
        .new-log-entry { animation: fadeSlideIn 0.35s ease-out; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.5} }
      `}</style>

      <div className="p-5 md:p-7 max-w-[1600px] mx-auto">

        {/* ── TOP BAR ────────────────────────────────────────── */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-7 gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div
                className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest px-3 py-1 rounded-full"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', color: 'var(--text-muted)' }}
              >
                <Clock size={10} />
                {/* BUG-03 fix: pakai currentDate (state) agar terupdate tiap menit */}
                {format(currentDate, 'EEEE, dd MMMM yyyy', { locale: indonesia })}
              </div>
              <LivePill connected={isLive} />
              {/* FITUR-04: badge status Odoo API Key */}
              {odooKeyStatus !== 'loading' && (
                <div
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider"
                  style={odooKeyStatus === 'active'
                    ? { background: 'rgba(16,185,129,0.10)', color: '#10b981', border: '1px solid rgba(16,185,129,0.25)' }
                    : { background: 'rgba(248,113,113,0.10)', color: '#f87171', border: '1px solid rgba(248,113,113,0.25)' }
                  }
                  title={odooKeyStatus === 'active' ? 'Odoo API Key aktif' : 'Odoo belum dikonfigurasi — buka Profil'}
                >
                  <Zap size={9} />
                  Odoo {odooKeyStatus === 'active' ? 'OK' : '!'}
                </div>
              )}
            </div>
            <h1
              className="text-[26px] font-black tracking-tight leading-tight"
              style={{ color: 'var(--text-primary)' }}
            >
              {userFullName ? `${getGreeting()}, ${userFullName.split(' ')[0]}` : 'NOC Dashboard'}
            </h1>
            <p className="text-xs mt-1 flex items-center gap-1.5" style={{ color: 'var(--text-muted)' }}>
              <Signal size={10} />
              Update terakhir: {formatDistanceToNow(lastUpdated, { addSuffix: true, locale: indonesia })}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {hasAccess(userRole, PERMISSIONS.OVERVIEW_ACTION) && (
              <div className="flex flex-col items-end gap-0.5">
                <button
                  onClick={handleSyncSheet}
                  disabled={isSyncing}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl font-semibold text-xs transition-all disabled:opacity-50"
                  style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'var(--text-secondary)' }}
                >
                  {isSyncing ? <RefreshCw size={13} className="animate-spin" style={{ color: '#10b981' }} /> : <Database size={13} style={{ color: '#10b981' }} />}
                  {isSyncing ? 'Syncing...' : 'Sync Sheet'}
                </button>
                {/* FITUR-05: timestamp last sync */}
                {lastSyncTime && (
                  <span className="text-[9px] font-mono" style={{ color: 'var(--text-muted)' }}>
                    Last: {format(lastSyncTime, 'HH:mm')}
                  </span>
                )}
              </div>
            )}
            {hasAccess(userRole, PERMISSIONS.OVERVIEW_ACTION) && (
              <button disabled className="flex items-center gap-2 px-3.5 py-2 rounded-xl font-semibold text-xs opacity-40 cursor-not-allowed"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', color: 'var(--text-muted)' }}>
                <Archive size={13} /> Archive
              </button>
            )}
            {hasAccess(userRole, PERMISSIONS.CLIENT_ADD) && (
              <Link href="/work-orders/create">
                <button
                  className="flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition-all"
                  style={{ background: 'var(--cta-bg)', color: 'var(--cta-text)' }}
                >
                  <Plus size={13} /> Buat WO Baru
                </button>
              </Link>
            )}
            <button
              onClick={fetchDashboardData}
              className="p-2 rounded-xl transition-all"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.09)', color: 'var(--text-muted)' }}
              title="Refresh data"
            >
              <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {/* ── APPROVAL BANNER ────────────────────────────────── */}
        {hasAccess(userRole, PERMISSIONS.OVERVIEW_ACTION) && pendingApprovals.length > 0 && (
          <div className="mb-5 rounded-2xl overflow-hidden" style={{ background: 'rgba(248,113,113,0.06)', border: '1px solid rgba(248,113,113,0.2)', backdropFilter: 'blur(16px)' }}>
            <div className="px-5 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(248,113,113,0.15)', background: 'rgba(248,113,113,0.05)' }}>
              <div className="flex items-center gap-3">
                <div className="p-1.5 rounded-lg" style={{ background: 'rgba(248,113,113,0.15)', color: '#f87171' }}><ShieldAlert size={15} /></div>
                <div>
                  <h3 className="text-sm font-bold" style={{ color: '#fca5a5' }}>Pending Discard Approvals</h3>
                  <p className="text-[11px]" style={{ color: 'rgba(248,113,113,0.7)' }}>Verifikasi pengabaian sinkronisasi data</p>
                </div>
              </div>
              <span className="text-[10px] font-bold px-2.5 py-1 rounded-full" style={{ background: 'rgba(248,113,113,0.15)', color: '#f87171', border: '1px solid rgba(248,113,113,0.25)' }}>
                {pendingApprovals.length} requests
              </span>
            </div>
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {pendingApprovals.map((item) => (
                <div key={item.id} className="rounded-xl p-3.5 flex flex-col gap-3" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded uppercase" style={{ background: 'rgba(16,185,129,0.1)', color: '#10b981', border: '1px solid rgba(16,185,129,0.2)' }}>{item.REQUESTED_BY || 'NOC'}</span>
                    <span className="text-[10px] font-mono" style={{ color: 'var(--text-muted)' }}>{item.created_at ? format(new Date(item.created_at), 'dd/MM HH:mm') : ''}</span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase leading-tight mb-1 line-clamp-2" style={{ color: 'var(--text-primary)' }}>{item.SUBJECT_IGNORED}</h4>
                    <p className="text-[11px] italic" style={{ color: 'var(--text-muted)' }}>"{item.ALASAN}"</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-auto">
                    <button onClick={() => handleApprovalAction(item.id, 'APPROVE')} className="flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-bold transition-all" style={{ background: 'var(--cta-bg)', color: 'var(--cta-text)' }}>
                      <Check size={12} /> Approve
                    </button>
                    <button onClick={() => handleApprovalAction(item.id, 'REJECT')} className="flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-bold transition-all" style={{ background: 'rgba(248,113,113,0.1)', border: '1px solid rgba(248,113,113,0.25)', color: '#f87171' }}>
                      <X size={12} /> Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <AlertBanner />

        {/* ── STAT CARDS ─────────────────────────────────────── */}
        {/* FITUR-06: hitung trend vs bulan lalu */}
        {(() => {
          const trendPct = prevMonthGrowth > 0
            ? Math.round(((realtimeStats.growthMonth - prevMonthGrowth) / prevMonthGrowth) * 100)
            : realtimeStats.growthMonth > 0 ? 100 : 0;
          const trendStr = trendPct > 0
            ? `+${trendPct}% vs bln lalu`
            : trendPct < 0 ? `${trendPct}% vs bln lalu` : null;

          return (
            // FITUR-01: tambah stat card Insiden Backbone — grid 5 kolom di desktop
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-5">
              <StatCard
                title="Total Client"
                value={<AnimatedNumber value={realtimeStats.totalClient} />}
                sub="Database aktif"
                icon={<Users size={18} />}
                accentColor="#38bdf8"
                trend={realtimeClients.length > stats.totalClient ? `+${realtimeClients.length - stats.totalClient} baru` : null}
              />
              <StatCard
                title="WO Aktif"
                value={<AnimatedNumber value={realtimeStats.woPending} />}
                sub="Pending & Progress"
                icon={<Activity size={18} />}
                accentColor="#a78bfa"
                trend={null}
              />
              <StatCard
                title="Bulan Ini"
                value={<AnimatedNumber value={realtimeStats.growthMonth} prefix="+" />}
                sub="Pelanggan baru"
                icon={<TrendingUp size={18} />}
                accentColor="#10b981"
                trend={trendStr}
                trendDown={trendPct < 0}
              />
              <StatCard
                title="VLAN Tersedia"
                value={<AnimatedNumber value={realtimeStats.totalVlanFree} />}
                sub={`${vlanUsagePercent}% slot terpakai`}
                icon={<Database size={18} />}
                accentColor="#fbbf24"
                trend={null}
                progress={vlanUsagePercent}
              />
              {/* FITUR-01: Insiden Backbone Aktif */}
              <StatCard
                title="Insiden Backbone"
                value={<AnimatedNumber value={backboneCount} />}
                sub="Tiket backbone aktif"
                icon={<WifiOff size={18} />}
                accentColor={backboneCount > 0 ? '#f87171' : '#10b981'}
                trend={backboneCount > 0 ? `${backboneCount} perlu ditangani` : null}
                trendDown={backboneCount > 0}
              />
            </div>
          );
        })()}

        {/* ── FITUR-02: WO Status Breakdown ───────────────────── */}
        {Object.keys(woBreakdown).length > 0 && (
          <div className="mb-5 card p-4">
            <h3 className="text-[11px] font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
              <Activity size={12} /> WO Status Breakdown
            </h3>
            <div className="flex flex-wrap gap-2">
              {[
                { key: 'OPEN',        color: '#38bdf8' },
                { key: 'ON PROGRESS', color: '#a78bfa' },
                { key: 'PROGRESS',    color: '#a78bfa' },
                { key: 'PENDING',     color: '#fbbf24' },
                { key: 'SOLVED',      color: '#10b981' },
                { key: 'CLOSED',      color: '#6b7280' },
                { key: 'UNSOLVED',    color: '#f87171' },
                { key: 'CANCEL',      color: '#ef4444' },
              ].filter(s => woBreakdown[s.key] > 0).map(s => (
                <div key={s.key}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl"
                  style={{ background: `${s.color}14`, border: `1px solid ${s.color}30` }}
                >
                  <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: s.color }} />
                  <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: s.color }}>{s.key}</span>
                  <span className="text-sm font-black" style={{ color: s.color }}>
                    <AnimatedNumber value={woBreakdown[s.key]} />
                  </span>
                </div>
              ))}
              {/* status tak dikenal */}
              {Object.entries(woBreakdown)
                .filter(([k]) => !['OPEN','ON PROGRESS','PROGRESS','PENDING','SOLVED','CLOSED','UNSOLVED','CANCEL'].includes(k))
                .map(([k, v]) => (
                  <div key={k} className="flex items-center gap-2 px-3 py-1.5 rounded-xl"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                    <span className="text-[10px] font-bold uppercase" style={{ color: 'var(--text-muted)' }}>{k}</span>
                    <span className="text-sm font-black" style={{ color: 'var(--text-secondary)' }}>{v}</span>
                  </div>
              ))}
            </div>
          </div>
        )}

        {/* ── MAIN GRID ───────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

          {/* ── CHART ──────────────────────────────────────────── */}
          <div className="card lg:col-span-2 flex flex-col overflow-hidden" style={{ padding: 0 }}>
            {/* Chart header */}
            <div className="px-5 pt-5 pb-0 shrink-0">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-3">
                <div>
                  <h3 className="font-bold flex items-center gap-2 text-[14px]" style={{ color: 'var(--text-primary)' }}>
                    {chartTab === 'CLIENT'
                      ? <><Users size={15} style={{ color: '#10b981' }} /> Pertumbuhan Pelanggan</>
                      : <><BarChart3 size={15} style={{ color: '#38bdf8' }} /> Pertumbuhan Kapasitas</>
                    }
                  </h3>
                  <p className="text-[10px] mt-0.5 uppercase tracking-wider font-semibold" style={{ color: 'var(--text-muted)' }}>Statistik 2026</p>
                </div>
                <div className="flex p-0.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <button
                    onClick={() => setChartTab('CLIENT')}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                    style={chartTab === 'CLIENT'
                      ? { background: 'rgba(16,185,129,0.15)', color: '#10b981', border: '1px solid rgba(16,185,129,0.25)' }
                      : { color: 'var(--text-muted)' }
                    }
                  >Pelanggan</button>
                  <button
                    onClick={() => setChartTab('CAPACITY')}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                    style={chartTab === 'CAPACITY'
                      ? { background: 'rgba(56,189,248,0.15)', color: '#38bdf8', border: '1px solid rgba(56,189,248,0.25)' }
                      : { color: 'var(--text-muted)' }
                    }
                  >Kapasitas</button>
                </div>
              </div>
            </div>

            {/* Chart — UX-01/FITUR-07: theme-aware + UX-04: empty state */}
            {(() => {
              const currentSeries = chartTab === 'CLIENT' ? chartData.client : chartData.capacity;
              const isEmpty = !currentSeries.length ||
                currentSeries.every((s: any) => (s.data || []).every((v: number) => v === 0));

              // UX-01/FITUR-07: warna label dan tooltip ikut tema
              const textColor    = isDark ? '#64748b' : '#64748b';
              const legendColor  = isDark ? '#94a3b8' : '#475569';
              const gridColor    = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.08)';
              const tooltipTheme = isDark ? 'dark' : 'light';
              const fillShade    = isDark ? 'dark' : 'light';

              return isEmpty ? (
                /* UX-04: empty state chart */
                <div className="flex-1 flex flex-col items-center justify-center gap-3 py-10">
                  <BarChart3 size={36} style={{ color: 'var(--text-muted)', opacity: 0.35 }} />
                  <p className="text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Belum ada data untuk periode ini</p>
                  <p className="text-[11px]" style={{ color: 'var(--text-muted)', opacity: 0.6 }}>Data akan muncul setelah ada transaksi di 2026</p>
                </div>
              ) : (
                <div className="flex-1 min-h-0 px-2">
                  <ReactApexChart
                    options={{
                      chart: {
                        toolbar: { show: false },
                        fontFamily: "'Inter', sans-serif",
                        background: 'transparent',
                        animations: { enabled: true, speed: 700 },
                      },
                      colors: chartTab === 'CLIENT' ? ['#10b981', '#f87171', '#fbbf24'] : ['#38bdf8', '#6b7280'],
                      xaxis: {
                        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
                        labels: { style: { fontSize: '11px', fontWeight: 500, colors: textColor } },
                        axisBorder: { color: gridColor },
                        axisTicks:  { color: gridColor },
                      },
                      yaxis: { labels: { style: { fontSize: '11px', colors: textColor } } },
                      grid: { borderColor: gridColor, strokeDashArray: 4 },
                      plotOptions: { bar: { borderRadius: 6, columnWidth: '50%', borderRadiusApplication: 'end' } },
                      legend: { fontSize: '12px', fontWeight: 600, offsetY: 4, labels: { colors: legendColor } },
                      dataLabels: { enabled: false },
                      tooltip: {
                        style: { fontFamily: "'Inter', sans-serif", fontSize: '12px' },
                        theme: tooltipTheme,
                      },
                      fill: {
                        type: 'gradient',
                        gradient: { shade: fillShade, type: 'vertical', shadeIntensity: 0.25, opacityFrom: 1, opacityTo: 0.75 },
                      },
                    }}
                    series={currentSeries}
                    type="bar"
                    height="100%"
                  />
                </div>
              );
            })()}

            {/* Chart Footer Summary */}
            <div className="mt-auto px-5 py-3.5" style={{ borderTop: '1px solid var(--border-light)', background: 'var(--bg-elevated)' }}>
              <div className="grid grid-cols-5 gap-2">
                {[
                  { label: 'Pasang', val: chartSummary.pasang, color: '#10b981' },
                  { label: 'Putus', val: chartSummary.putus, color: '#f87171' },
                  { label: 'Berhenti Smtr', val: chartSummary.BerhentiSementara, color: '#fbbf24' },
                  { label: 'Upgrade', val: chartSummary.upgrade, color: '#38bdf8' },
                  { label: 'Downgrade', val: chartSummary.downgrade, color: '#6b7280' },
                ].map((item) => (
                  <div key={item.label} className="text-center">
                    <p className="text-[9px] uppercase font-bold tracking-wider mb-1" style={{ color: 'var(--text-muted)' }}>{item.label}</p>
                    <p className="text-base font-black" style={{ color: item.color, textShadow: `0 0 12px ${item.color}60` }}>{item.val}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ── RIGHT COLUMN ────────────────────────────────────── */}
          <div className="flex flex-col gap-4">

            {/* Jadwal Tim */}
            <div className="card p-4">
              <h3 className="font-bold mb-3 flex items-center gap-2 text-[13px]" style={{ color: 'var(--text-primary)' }}>
                <div className="p-1.5 rounded-lg" style={{ background: 'rgba(56,189,248,0.12)', color: '#38bdf8' }}><Calendar size={13} /></div>
                Jadwal Tim Aktivator
              </h3>
              <div className="space-y-2.5">
                <div className="p-3 rounded-xl" style={{ background: 'rgba(251,191,36,0.07)', border: '1px solid rgba(251,191,36,0.18)' }}>
                  <p className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: '#fbbf24' }}>Pagi · 08.00–16.00</p>
                  <div className="flex gap-2">
                    {morningSquad.map((name, i) => (
                      <span key={i} className="flex-1 text-center text-xs font-semibold py-1.5 rounded-lg" style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--text-primary)', border: '1px solid rgba(251,191,36,0.2)' }}>{name}</span>
                    ))}
                  </div>
                </div>
                <div className="p-3 rounded-xl" style={{ background: 'rgba(56,189,248,0.07)', border: '1px solid rgba(56,189,248,0.18)' }}>
                  <p className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: '#38bdf8' }}>Siang · 14.00–22.00</p>
                  <div className="flex gap-2">
                    {afternoonSquad.map((name, i) => (
                      <span key={i} className="flex-1 text-center text-xs font-semibold py-1.5 rounded-lg" style={{ background: 'rgba(255,255,255,0.06)', color: 'var(--text-primary)', border: '1px solid rgba(56,189,248,0.2)' }}>{name}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Aktivitas Terkini — Realtime */}
            <div className="card flex flex-col flex-1 overflow-hidden" style={{ padding: 0 }}>
              <div className="px-4 py-3 flex justify-between items-center" style={{ borderBottom: '1px solid var(--border-light)' }}>
                <h3 className="font-bold text-[13px]" style={{ color: 'var(--text-primary)' }}>Aktivitas Terkini</h3>
                <div className="flex items-center gap-2">
                  <LivePill connected={isLive} />
                  <Link href="/logs" className="p-1.5 rounded-lg transition-colors" style={{ color: 'var(--text-muted)' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = '#10b981'; (e.currentTarget as HTMLElement).style.background = 'rgba(16,185,129,0.1)'; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = 'var(--text-muted)'; (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
                  >
                    <List size={14} />
                  </Link>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar" style={{ maxHeight: '280px' }}>
                {recentLogs.length === 0 ? (
                  <p className="p-5 text-center text-xs italic" style={{ color: 'var(--text-muted)' }}>Belum ada aktivitas</p>
                ) : recentLogs.map((log, idx) => (
                  <div
                    key={log.id}
                    className={`px-4 py-2.5 flex gap-3 transition-colors ${idx === 0 ? 'new-log-entry' : ''}`}
                    style={{ borderBottom: '1px solid var(--border-light)' }}
                    onMouseEnter={e => ((e.currentTarget as HTMLElement).style.background = 'var(--bg-elevated)')}
                    onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = 'transparent')}
                  >
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0 uppercase mt-0.5"
                      style={{ background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.2)', color: '#10b981' }}
                    >
                      {log.actor?.substring(0, 2) || 'SY'}
                    </div>
                    <div className="overflow-hidden min-w-0 flex-1">
                      <div className="flex justify-between items-start gap-1">
                        <p className="text-[11px] font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{log.actor}</p>
                        <p className="text-[9px] shrink-0 font-mono" style={{ color: 'var(--text-muted)' }}>{log.created_at ? format(new Date(log.created_at), 'HH:mm') : '-'}</p>
                      </div>
                      <p className="text-[11px] truncate mt-0.5" style={{ color: 'var(--text-secondary)' }}>{log.SUBJECT}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── VLAN USAGE BAR ─────────────────────────────────── */}
        <div className="mt-5 card p-5">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl" style={{ background: 'rgba(251,191,36,0.1)', color: '#fbbf24' }}><Database size={15} /></div>
              <div>
                <h3 className="font-bold text-[13px]" style={{ color: 'var(--text-primary)' }}>Kapasitas VLAN</h3>
                <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>Kapasitas slot VLAN keseluruhan</p>
              </div>
            </div>
            <div className="text-right">
              <p
                className="text-2xl font-black"
                style={{
                  color: vlanUsagePercent > 85 ? '#f87171' : vlanUsagePercent > 60 ? '#fbbf24' : '#10b981',
                  textShadow: `0 0 20px ${vlanUsagePercent > 85 ? 'rgba(248,113,113,0.4)' : vlanUsagePercent > 60 ? 'rgba(251,191,36,0.4)' : 'rgba(16,185,129,0.4)'}`,
                }}
              >{vlanUsagePercent}%</p>
              <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{realtimeStats.totalVlanUsed} / {realtimeStats.totalVlanFree + realtimeStats.totalVlanUsed} terpakai</p>
            </div>
          </div>
          <div className="w-full rounded-full h-3 overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{
                width: `${vlanUsagePercent}%`,
                background: vlanUsagePercent > 85
                  ? 'linear-gradient(90deg, #ef4444, #f87171)'
                  : vlanUsagePercent > 60
                  ? 'linear-gradient(90deg, #d97706, #fbbf24)'
                  : 'linear-gradient(90deg, #059669, #10b981, #34d399)',
                boxShadow: vlanUsagePercent > 85 ? '0 0 12px rgba(248,113,113,0.5)' : vlanUsagePercent > 60 ? '0 0 12px rgba(251,191,36,0.4)' : '0 0 12px rgba(16,185,129,0.4)',
              }}
            />
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>0%</span>
            <span className="text-[10px] font-bold" style={{ color: vlanUsagePercent > 85 ? '#f87171' : vlanUsagePercent > 60 ? '#fbbf24' : '#10b981' }}>
              {vlanUsagePercent > 85 ? '⚠ Kapasitas kritis!' : vlanUsagePercent > 60 ? 'Perlu perhatian' : '✓ Normal'}
            </span>
            <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>100%</span>
          </div>
        </div>

      </div>

      {/* ── FLOATING INBOX BUTTON ──────────────────────────── */}
      <button
        onClick={() => setShowInbox(true)}
        className="fixed bottom-6 right-6 z-40 bg-blue-600 hover:bg-blue-700 text-white p-3.5 rounded-full shadow-lg transition-all hover:scale-105 active:scale-95 flex items-center justify-center"
      >
        <ListTodo size={20} />
        {myInboxTickets.length > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white">
            {myInboxTickets.length}
          </span>
        )}
      </button>

      {/* ── INBOX MODAL ────────────────────────────────────── */}
      {showInbox && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}>
          <div className="w-full max-w-2xl rounded-2xl flex flex-col max-h-[85vh] overflow-hidden"
            style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-mid)', boxShadow: '0 32px 80px rgba(0,0,0,0.6)', fontFamily: "'Inter', sans-serif" }}>

            {/* Header */}
            <div className="px-5 py-4" style={{ borderBottom: '1px solid var(--border-light)', background: 'var(--bg-elevated)' }}>
              <div className="flex justify-between items-center mb-3">
                <div>
                  <h2 className="text-sm font-bold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                    <div className="p-1 rounded-lg" style={{ background: 'rgba(56,189,248,0.12)', color: '#38bdf8' }}>
                      <Inbox size={14} />
                    </div>
                    Inbox Tugas Utama
                  </h2>
                  <p className="text-[10px] uppercase tracking-wider font-semibold mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    {userRole === 'SUPER_DEV' ? 'Monitoring PIC' : 'Daftar Paket Work Order'}
                  </p>
                </div>
                <button
                  onClick={() => setShowInbox(false)}
                  className="p-1.5 rounded-lg transition-colors"
                  style={{ color: 'var(--text-muted)' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--bg-subtle)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-primary)'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-muted)'; }}
                >
                  <X size={16} />
                </button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" size={13} style={{ color: 'var(--text-muted)' }} />
                <input
                  type="text"
                  placeholder="Cari nomor tiket, PIC, atau nama WO..."
                  value={searchTicket}
                  onChange={e => setSearchTicket(e.target.value)}
                  className="w-full pl-8 pr-4 py-2 rounded-lg text-xs font-medium outline-none transition-all"
                  style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-mid)', color: 'var(--text-primary)' }}
                  onFocus={e => { e.currentTarget.style.borderColor = 'var(--accent-border)'; e.currentTarget.style.boxShadow = '0 0 0 3px var(--accent-bg)'; }}
                  onBlur={e => { e.currentTarget.style.borderColor = 'var(--border-mid)'; e.currentTarget.style.boxShadow = 'none'; }}
                />
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2" style={{ background: 'var(--bg-base)' }}>
              {myInboxTickets
                // UX-02 fix: search juga berdasarkan PIC dan nama WO
                .filter(t => {
                  const q = searchTicket.toLowerCase().trim();
                  if (!q) return true;
                  const matchId  = (t.id_tiket_custom || '').toLowerCase().includes(q);
                  const matchPic = (t.assigned_to || '').toLowerCase().includes(q);
                  const matchWo  = (t.details || []).some((wo: any) =>
                    (wo['SUBJECT WO'] || '').toLowerCase().includes(q)
                  );
                  return matchId || matchPic || matchWo;
                })
                .map(ticket => {
                  const isExpanded = expandedTicket === ticket.id;
                  return (
                    <div key={ticket.id} className="rounded-xl overflow-hidden transition-all"
                      style={{ border: `1px solid ${isExpanded ? 'rgba(56,189,248,0.3)' : 'var(--border-light)'}`, background: 'var(--bg-surface)' }}>
                      <button
                        onClick={() => setExpandedTicket(isExpanded ? null : ticket.id)}
                        className="w-full flex items-center justify-between p-3.5 text-left transition-colors"
                        style={{ background: isExpanded ? 'rgba(56,189,248,0.07)' : 'transparent' }}
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-1.5 rounded-lg transition-colors"
                            style={isExpanded
                              ? { background: '#0284c7', color: '#fff' }
                              : { background: 'var(--bg-elevated)', color: 'var(--text-muted)' }
                            }>
                            <ListTodo size={14} />
                          </div>
                          <div>
                            <h3 className="font-bold text-xs uppercase tracking-tight" style={{ color: 'var(--text-primary)' }}>
                              {ticket.id_tiket_custom || 'BATCH'}
                            </h3>
                            <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                              {ticket.details.length} WOs{userRole === 'SUPER_DEV' ? ` · PIC: ${ticket.assigned_to}` : ''}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full border"
                            style={ticket.status === 'SOLVED'
                              ? { background: 'rgba(16,185,129,0.12)', color: '#34d399', borderColor: 'rgba(16,185,129,0.25)' }
                              : { background: 'rgba(245,158,11,0.12)', color: '#fbbf24', borderColor: 'rgba(245,158,11,0.25)' }
                            }>
                            {ticket.status}
                          </span>
                          {isExpanded
                            ? <ChevronDown size={14} style={{ color: 'var(--text-muted)' }} />
                            : <ChevronRight size={14} style={{ color: 'var(--text-muted)' }} />}
                        </div>
                      </button>
                      {isExpanded && (
                        <div className="px-4 pb-3 pt-2 space-y-2" style={{ borderTop: '1px solid rgba(56,189,248,0.12)', background: 'rgba(56,189,248,0.04)' }}>
                          {ticket.details.map((wo: any) => (
                            <div key={wo.id} className="flex items-center justify-between p-2.5 rounded-lg"
                              style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-light)' }}>
                              <div className="flex-1 pr-3 min-w-0">
                                <h4 className="font-semibold text-xs truncate" style={{ color: 'var(--text-primary)' }}>{wo['SUBJECT WO']}</h4>
                                <p className="text-[10px] italic truncate mt-0.5" style={{ color: 'var(--text-muted)' }}>{wo.KETERANGAN || '-'}</p>
                              </div>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0"
                                style={wo.STATUS === 'SOLVED'
                                  ? { background: 'rgba(16,185,129,0.12)', color: '#34d399', borderColor: 'rgba(16,185,129,0.25)' }
                                  : { background: 'rgba(245,158,11,0.12)', color: '#fbbf24', borderColor: 'rgba(245,158,11,0.25)' }
                                }>
                                {wo.STATUS}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>

            {/* Footer */}
            <div className="px-5 py-3 flex justify-between items-center"
              style={{ borderTop: '1px solid var(--border-light)', background: 'var(--bg-elevated)' }}>
              <span className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{myInboxTickets.length} Tiket Aktif</span>
              <button
                onClick={handleDownloadInbox}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                style={{ background: 'var(--bg-subtle)', border: '1px solid var(--border-mid)', color: 'var(--text-secondary)' }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--accent-bg)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--accent)'; (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--accent-border)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--bg-subtle)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-secondary)'; (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border-mid)'; }}
              >
                <Download size={13} /> Download .txt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── STAT CARD ────────────────────────────────────────────────
// FITUR-06: prop trendDown untuk warna merah saat tren turun
function StatCard({ title, value, sub, icon, accentColor, trend, progress, trendDown }: any) {
  const color = accentColor || '#f0efe8';
  const trendColor  = trendDown ? '#f87171' : '#34d399';
  const trendBg     = trendDown ? 'rgba(248,113,113,0.12)' : 'rgba(16,185,129,0.12)';
  const trendBorder = trendDown ? 'rgba(248,113,113,0.2)'  : 'rgba(16,185,129,0.2)';
  return (
    <div className="stat-card p-4 relative overflow-hidden group" style={{ borderRadius: 14 }}>
      {/* Top glow line */}
      <div className="absolute top-0 left-0 w-full h-[2px] rounded-t-[20px]"
        style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)`, opacity: 0.7 }} />
      {/* Ambient corner glow */}
      <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full pointer-events-none"
        style={{ background: `radial-gradient(circle, ${color}22 0%, transparent 70%)` }} />

      <div className="flex justify-between items-start mb-3 relative z-10">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center"
          style={{ background: `${color}1a`, border: `1px solid ${color}33`, color }}>
          {icon}
        </div>
        {trend && (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5"
            style={{ background: trendBg, color: trendColor, border: `1px solid ${trendBorder}` }}>
            {trendDown ? <ArrowDownRight size={10} /> : <ArrowUpRight size={10} />}{trend}
          </span>
        )}
      </div>

      <p className="text-2xl font-bold leading-none mb-1 relative z-10"
        style={{ color: 'var(--text-primary)' }}>{value}</p>
      <p className="text-xs font-semibold relative z-10" style={{ color: 'var(--text-secondary)' }}>{title}</p>
      <p className="text-[11px] mt-0.5 relative z-10" style={{ color: 'var(--text-muted)' }}>{sub}</p>

      {progress !== undefined && (
        <div className="mt-3 w-full rounded-full h-1.5 overflow-hidden relative z-10"
          style={{ background: 'rgba(255,255,255,0.07)' }}>
          <div className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${progress}%`,
              background: progress > 85
                ? 'linear-gradient(90deg,#ef4444,#f87171)'
                : progress > 60
                  ? 'linear-gradient(90deg,#f59e0b,#fcd34d)'
                  : `linear-gradient(90deg,${color},${color}cc)`,
              boxShadow: `0 0 8px ${progress > 85 ? '#ef4444' : progress > 60 ? '#f59e0b' : color}66`,
            }} />
        </div>
      )}
    </div>
  );
}

// ── MINI STAT CARD ───────────────────────────────────────────
function MiniStatCard({ label, value, icon, color }: any) {
  // color is now a hex string e.g. "#fbbf24"
  const c = color || '#10b981';
  return (
    <div className="card p-3.5 flex items-center gap-3" style={{ borderRadius: 12 }}>
      <div className="p-2 rounded-xl flex items-center justify-center"
        style={{ background: `${c}1a`, border: `1px solid ${c}30`, color: c }}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-bold uppercase tracking-wider" style={{ color: `${c}bb` }}>{label}</p>
        <p className="text-xl font-bold" style={{ color: c }}>{value}</p>
      </div>
    </div>
  );
}

// ── SKELETON ────────────────────────────────────────────────
function DashboardSkeleton() {
  const shimmer = {
    background: 'var(--bg-surface)',
    borderRadius: 12,
    border: '1px solid var(--border-light)',
    animation: 'pulse 2s cubic-bezier(0.4,0,0.6,1) infinite',
  } as React.CSSProperties;
  return (
    <div className="p-5 md:p-7" style={{ background: 'var(--bg-base)', minHeight: '100vh' }}>
      <style>{`@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`}</style>
      <div style={{ ...shimmer, height: 24, width: 160, marginBottom: 6 }} />
      <div style={{ ...shimmer, height: 16, width: 224, marginBottom: 28 }} />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        {[1,2,3,4].map(i => <div key={i} style={{ ...shimmer, height: 112 }} />)}
      </div>
      <div className="grid grid-cols-3 gap-4 mb-5">
        {[1,2,3].map(i => <div key={i} style={{ ...shimmer, height: 64 }} />)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2" style={{ ...shimmer, height: 288 }} />
        <div className="flex flex-col gap-4">
          <div style={{ ...shimmer, height: 128 }} />
          <div style={{ ...shimmer, height: 192 }} />
        </div>
      </div>
    </div>
  );
}